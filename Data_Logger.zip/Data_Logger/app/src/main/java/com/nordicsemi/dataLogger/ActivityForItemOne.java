package com.nordicsemi.dataLogger;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;


public class ActivityForItemOne extends Activity {

    public static final String TAG = "--nRFUART";
    private  EditText ageInput;
    private  EditText weightInput;
    private  EditText heightInput;
    private  Switch switchInput;
    private static UartService mService = null;

    private static int Age;
    private static float Weight;
    private static float Height;
    private static boolean buttonChecked;// True=ON=MALE / False=OFF=FEMALE



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_for_item_one);

        ageInput = (EditText) findViewById(R.id.ageInputID);
        weightInput = (EditText) findViewById(R.id.weightInputID);
        heightInput = (EditText) findViewById(R.id.heightInputID);
        switchInput = (Switch)findViewById(R.id.sexSwitchID);

        final Button doneButton = (Button) findViewById(R.id.doneID);

        doneButton.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        Intent intent = new Intent();
                        Age = Integer.parseInt(ageInput.getText().toString());
                        Weight = Float.parseFloat(weightInput.getText().toString());
                        Height = Float.parseFloat(heightInput.getText().toString());
                        buttonChecked = switchInput.isChecked();
                        intent.putExtra("Age" , Age);
                        intent.putExtra("Weight" , Weight);
                        intent.putExtra("Height", Height);
                        if(buttonChecked)//male
                            intent.putExtra("Sex" , 1);
                        else//female
                            intent.putExtra("Sex" , 0);


                        Log.d(TAG, "+AGE = " + Age);
                        Log.d(TAG, "+SEX = " + buttonChecked) ;
                        Log.d(TAG, "+WEIGHT = " + Weight);
                        Log.d(TAG, "+HEIGHT = " + Height);


                        setResult(RESULT_OK , intent );
                        finish();
                    }
                }

        );

    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_for_item_one, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);
    }
}
