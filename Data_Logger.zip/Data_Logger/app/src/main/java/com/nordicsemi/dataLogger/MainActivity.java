
/*
 * Copyright (c) 2015, Nordic Semiconductor
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.nordicsemi.dataLogger;




import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Parcelable;
import android.support.v4.content.LocalBroadcastManager;
import android.text.format.Time;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.Formatter;


//THIS IS THE APP!!!
public class MainActivity extends Activity  {

    private static final String FILE_HEADER = "ax,ay,az,@100Hz";
    private static final String NEW_LINE_SEPARATOR = "\n";
    private static final String COMMA_DELIMITER = ",";


    static final float TWO_PI = 6.283185307179586f;
    private static final int REQUEST_SELECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int UART_PROFILE_READY = 10;
    public static final String TAG = "--nRFUART";
    private static final int UART_PROFILE_CONNECTED = 20;
    private static final int UART_PROFILE_DISCONNECTED = 21;
    private static final int STATE_OFF = 10;

    private static final int USER_PROFILE_INPUT = 100;
    private static byte [] Age = new byte[1];
    private static float Height;
    private static float Weight;
    private static byte [] Sex = new byte[1];

    private static final int TRAINING_DEVICE = 200;
    private static byte trainingIDSelector;

    private TextView energyExpenditure_text;
    private TextView power_text;
    private TextView timer;
    private TextView EE_OUTPUT;
    private ImageView myImageView;
    TextView mRemoteRssiVal;
    RadioGroup mRg;
    private int mState = UART_PROFILE_DISCONNECTED;
    private UartService mService = null;
    private BluetoothDevice mDevice = null;
    private BluetoothAdapter mBtAdapter = null;
    //private ListView messageListView;
    private ArrayAdapter<String> listAdapter;
    private Button btnConnectDisconnect;
    //private EditText edtMessage;

    private boolean trainingDataRX = false;
    private boolean powerRX = false;
    private boolean  energy_expenditureRX = false;

    private static final float sampling_freq = 100.0f;
    private static final float data_time_length = 4.0f;
    private static final float total_data_time_length = 30.0f;
    private static  int xyz_size = (int)(total_data_time_length * sampling_freq);//had final
    private static float  [] ax;// = new float[xyz_size]; //Accelerometer x training data
    private static float  [] ay;// = new float[xyz_size]; //Accelerometer y training data
    private static float  [] az;// = new float[xyz_size]; //Accelerometer z training data
    private static final float ref_time_length = 1.5f;
    private static final int num_samples = 10;
    private static final int   downsamp_fact    = 4;//-----------------------






    static final int data_num_elements = (int)(sampling_freq * data_time_length);
    static final int data_downsamp_num_elements      = data_num_elements / downsamp_fact;//
    static int data_freq_downsamp_num_elements = data_downsamp_num_elements + 2;//402/202/102/52

   private static float [] reference_x;// = new float [data_num_elements *4 ];
   private static float [] reference_y;// = new float [data_num_elements *4 ];
   private static float [] reference_z;// = new float [data_num_elements *4 ];
   private static float [] workspace;// = new float[6200];

    private int xyz_pointer = 0;
    int number_of_samples_acquired = 0;

    byte [] reference_x_bytes;
    byte [] reference_y_bytes;
    byte [] reference_z_bytes;



    private float power_value = 0;
    private float energy_expenditure_value = 0;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.d(TAG, "onCreate");
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBtAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        //messageListView = (ListView) findViewById(R.id.listMessage);
        listAdapter = new ArrayAdapter<String>(this, R.layout.message_detail);
        //messageListView.setAdapter(listAdapter);
        //messageListView.setDivider(null);
        btnConnectDisconnect=(Button) findViewById(R.id.btn_select);

        //power_text = (TextView) findViewById(R.id.powerText);
        timer = (TextView) findViewById(R.id.textView);


        //edtMessage = (EditText) findViewById(R.id.sendText);
        service_init();


       
        // Handle Disconnect & Connect button
        btnConnectDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mBtAdapter.isEnabled()) {
                    Log.i(TAG, "onClick - BT not enabled yet");
                    Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
                } else {
                    if (btnConnectDisconnect.getText().equals("Connect")) {

                        //Connect button pressed, open DeviceListActivity class, with popup windows that scan for devices

                        Intent newIntent = new Intent(MainActivity.this, DeviceListActivity.class);
                        startActivityForResult(newIntent, REQUEST_SELECT_DEVICE);
                    } else {
                        //Disconnect button pressed
                        if (mDevice != null) {
                            mService.disconnect();

                        }
                    }
                }
            }
        });


        final Button trainButton = (Button)findViewById(R.id.trainButton);//Train Button Input

        trainButton.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        Log.d(TAG, "trainingIDSelector = " + trainingIDSelector);
                        startActivityForResult(new Intent(MainActivity.this, TrainActivity.class), TRAINING_DEVICE);
                        Log.d(TAG, "trainingIDSelector = " + trainingIDSelector);
                    }
                }
        );



        final Button stopButton = (Button)findViewById(R.id.stopButton);//Stop Button Input
        stopButton.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        if (v == stopButton) {
                            myImageView.setVisibility(View.GONE);  // make image invisible
                            byte[] value = new byte[1];
                            value[0] = 99;
                            mService.writeRXCharacteristic(value);
                            timer.setText("");
                            Log.d(TAG, "Sending 99!");
                        }
                    }
                }
        );


    }

    private void createFile() {

        Time now = new Time();
        now.setToNow();
        String sTime = now.format("%Y_%m_%d_%H_%M");

        String newFile = sTime+".csv";

        File dir = new File("/storage/emulated/0/DataLogger");// The Directory
        dir.mkdirs();
        File f = new File(dir, newFile);//The file name that will be stored in directory

        String fileName = "/storage/emulated/0/DataLogger/" + newFile;//The File name and location
        final Formatter x; //To create a new .CSV or .TXT file
        FileWriter fw = null;
        Log.d(TAG,fileName);
        Log.d(TAG,newFile);

        if(f.exists()){
            Log.d(TAG, f.getName() + " exists!");
        }
        else{
            Log.d(TAG, "File Doesn't Exist, Creating The File Now!");

            try{
                x = new Formatter(fileName);//Create a new file .csv or .txt
                Log.d(TAG, "You Created A File!");

            }
            catch(Exception e){
                Log.d(TAG, "You got an Error");
            }


        }

        try{

            fw = new FileWriter(fileName, false);//false = overwrite/create new file , true = appends to file

            fw.append(FILE_HEADER.toString());
            fw.append(NEW_LINE_SEPARATOR);
            for(int i = 0 ; i < ax.length; i++){
                fw.append(Float.toString(ax[i]));
                fw.append(COMMA_DELIMITER);
                fw.append(Float.toString(ay[i]));
                fw.append(COMMA_DELIMITER);
                fw.append(Float.toString(az[i]));
                fw.append(COMMA_DELIMITER);
                fw.append(NEW_LINE_SEPARATOR);


            }
            Log.d(TAG, "About to close!");

            fw.close();
            Log.d(TAG, "Write was a Success!");

        }
        catch(Exception e){
            Log.d(TAG, "Error writing to CSV file !!!");

        }

//*/
    }
    // Set initial UI state
        

    //UART service connected/disconnected
    private ServiceConnection mServiceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder rawBinder) {
        		mService = ((UartService.LocalBinder) rawBinder).getService();
        		Log.d(TAG, "onServiceConnected mService= " + mService);
        		if (!mService.initialize()) {
                    Log.e(TAG, "Unable to initialize Bluetooth");
                    finish();
                }

        }

        public void onServiceDisconnected(ComponentName classname) {
       ////     mService.disconnect(mDevice);
        		mService = null;
        }
    };

    private static Handler mHandler = new Handler() {
        @Override
        
        //Handler events that received from UART service 
        public void handleMessage(Message msg) {
  
        }
    };

    private final BroadcastReceiver UARTStatusChangeReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            final Intent mIntent = intent;
           //*********************//
            if (action.equals(UartService.ACTION_GATT_CONNECTED)) {
            	 runOnUiThread(new Runnable() {
                     public void run() {
                         	String currentDateTimeString = DateFormat.getTimeInstance().format(new Date());
                             Log.d(TAG, "UART_CONNECT_MSG");
                             btnConnectDisconnect.setText("Disconnect");
                             //edtMessage.setEnabled(true);
                             //btnSend.setEnabled(true);
                             ((TextView) findViewById(R.id.deviceName)).setText(mDevice.getName() + " - ready");
                             listAdapter.add("[" + currentDateTimeString + "] Connected to: " + mDevice.getName());
                        	 	//messageListView.smoothScrollToPosition(listAdapter.getCount() - 1);
                             mState = UART_PROFILE_CONNECTED;
                     }
            	 });
            }
           
          //*********************//
            if (action.equals(UartService.ACTION_GATT_DISCONNECTED)) {
            	 runOnUiThread(new Runnable() {
                     public void run() {
                    	 	 String currentDateTimeString = DateFormat.getTimeInstance().format(new Date());
                             Log.d(TAG, "UART_DISCONNECT_MSG");
                             btnConnectDisconnect.setText("Connect");
                             //edtMessage.setEnabled(false);
                             //btnSend.setEnabled(false);
                             ((TextView) findViewById(R.id.deviceName)).setText("Not Connected");
                             listAdapter.add("[" + currentDateTimeString + "] Disconnected to: " + mDevice.getName());
                             mState = UART_PROFILE_DISCONNECTED;
                             mService.close();
                            //setUiState();
                         
                     }
                 });
            }
            
          
          //*********************//
            if (action.equals(UartService.ACTION_GATT_SERVICES_DISCOVERED)) {
             	 mService.enableTXNotification();
            }
          //*********************//
            if (action.equals(UartService.ACTION_DATA_AVAILABLE)) {

                final byte[] txValue = intent.getByteArrayExtra(UartService.EXTRA_DATA);
                final int txValue_size = txValue.length;

                Log.d(TAG, "Received " + txValue_size + " BYTES!!");
               // Log.d(TAG, "txValue[0] " + txValue[0]);

                if(txValue_size == 1 && txValue[0] == 3){//Get ready to receive 30 sec of training Data
                    Log.d(TAG, "Received 3!");
                    Log.d(TAG, "Getting Ready to receive 30 sec of training data");

                    trainingDataRX = true; // set flag to true to know that we are receiving training accelerometer data
                    //Clear the accelerometer data
                    ax = new float[xyz_size];
                    ay = new float[xyz_size];
                    az = new float[xyz_size];
                    xyz_pointer = 0;
                    byte [] value = new byte[1];
                    value[0] = 4;
                    Log.d(TAG, "Sending 4!");
                    mService.writeRXCharacteristic(value);//Send Acc training Data to the App

                }
                else if(txValue_size == 1 && txValue[0] == 5){//Finish acquiring 30 sec of training data
                    Log.d(TAG, "Received 5!");
                    Log.d(TAG, "Finish acquiring 30 sec of training data");
                    trainingDataRX = false;
                    Log.d(TAG, "Done Collecting all data");
                    timer.setText("Done!");
                    printReceive();
                    createFile();

                    //initiate_training();//create the reference data
                    ax = null;
                    ay = null;
                    az = null;

                }
                else if(txValue_size == 1 && txValue[0] == 50){
                    myImageView.setImageResource(R.drawable.walking);
                    myImageView.setVisibility(View.VISIBLE);  // make image visible
                    timer.setText("You are Walking!");
                }
                else if(txValue_size == 1 && txValue[0] == 51){
                    myImageView.setImageResource(R.drawable.jogging);
                    myImageView.setVisibility(View.VISIBLE);  // make image visible
                    timer.setText("You are Jogging!");
                }
                else if(txValue_size == 1 && txValue[0] == 52){
                    myImageView.setImageResource(R.drawable.running);
                    myImageView.setVisibility(View.VISIBLE);  // make image visible
                    timer.setText("You are Running!");
                }
                else if(txValue_size == 1 && txValue[0] == 53){
                    myImageView.setImageResource(R.drawable.biking);
                    myImageView.setVisibility(View.VISIBLE);  // make image visible
                    timer.setText("You are Biking!");
                }
                else if(txValue_size == 1 && txValue[0] == 0){
                    myImageView.setImageResource(R.drawable.redx);
                    myImageView.setVisibility(View.VISIBLE);  // make image visible
                    timer.setText("Unknown Activity!");
                }
                else {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                //String text = new String(txValue, "US-ASCII");
                                //THE NRF8001 CAN ONLY SEND 20 BYTES AT TIME
                                //SO WE CAN ONLY RECEIVE 18/12/6 BYTES AT TIME FOR X,Y,Z
                                if (trainingDataRX) {
                                   // Log.d(TAG, "trainingDataRx = " + trainingDataRX);
                                   // Log.d(TAG, "Received " + txValue_size + "bytes!");
                                   // Log.d(TAG, "txValue[0]  = " + txValue[0]);


                                    if (txValue_size == 18) {
                                       // Log.d(TAG, "Received 18 bytes!");

                                        ax[xyz_pointer] = (float) ((short) ((txValue[0] & 0xFF) | (txValue[1]) << 8))/250;
                                        ay[xyz_pointer] = (float) ((short) ((txValue[2] & 0xFF) | (txValue[3]) << 8))/250;
                                        az[xyz_pointer] = (float) ((short) ((txValue[4] & 0xFF) | (txValue[5]) << 8))/250;
                                        xyz_pointer++;

                                        ax[xyz_pointer] = (float) ((short) ((txValue[6] & 0xFF) | (txValue[7]) << 8))/250;
                                        ay[xyz_pointer] = (float) ((short) ((txValue[8] & 0xFF) | (txValue[9]) << 8))/250;
                                        az[xyz_pointer] = (float) ((short) ((txValue[10] & 0xFF) | (txValue[11]) << 8))/250;
                                        xyz_pointer++;

                                        ax[xyz_pointer] = (float) ((short) ((txValue[12] & 0xFF) | (txValue[13]) << 8))/250;
                                        ay[xyz_pointer] = (float) ((short) ((txValue[14] & 0xFF) | (txValue[15]) << 8))/250;
                                        az[xyz_pointer] = (float) ((short) ((txValue[16] & 0xFF) | (txValue[17]) << 8))/250;
                                        xyz_pointer++;
                                        number_of_samples_acquired += 3;
                                    } else if (txValue_size == 12) {
                                        //Log.d(TAG, "Received 12 bytes!");
                                        ax[xyz_pointer] = (float) ((short) ((txValue[0] & 0xFF) | (txValue[1]) << 8))/250;
                                        ay[xyz_pointer] = (float) ((short) ((txValue[2] & 0xFF) | (txValue[3]) << 8))/250;
                                        az[xyz_pointer] = (float) ((short) ((txValue[4] & 0xFF) | (txValue[5]) << 8))/250;
                                        xyz_pointer++;

                                        ax[xyz_pointer] = (float) ((short) ((txValue[6] & 0xFF) | (txValue[7]) << 8))/250;
                                        ay[xyz_pointer] = (float) ((short) ((txValue[8] & 0xFF) | (txValue[9]) << 8))/250;
                                        az[xyz_pointer] = (float) ((short) ((txValue[10] & 0xFF) | (txValue[11]) << 8))/250;
                                        xyz_pointer++;
                                        number_of_samples_acquired += 2;


                                    } else if (txValue_size == 6) {
                                        //Log.d(TAG, "Received 6 bytes!");
                                        ax[xyz_pointer] = (float) ((short) ((txValue[0] & 0xFF) | (txValue[1]) << 8))/100;
                                        ay[xyz_pointer] = (float) ((short) ((txValue[2] & 0xFF) | (txValue[3]) << 8))/100;
                                        az[xyz_pointer] = (float) ((short) ((txValue[4] & 0xFF) | (txValue[5]) << 8))/100;
                                        xyz_pointer++;
                                        number_of_samples_acquired += 1;

                                    }

                                } else if (energy_expenditureRX) {
                                    //timer.setText("");
                                    byte [] ENERGY = new byte[4];
                                    ENERGY [0] = txValue[3];
                                    ENERGY [1] = txValue[2];
                                    ENERGY [2] = txValue[1];
                                    ENERGY [3] = txValue[0];
                                    energy_expenditureRX = false;
                                    energy_expenditure_value = bytearray2float(ENERGY);
                                    EE_OUTPUT.setText(energy_expenditure_value + " kCal");

                                } else if (powerRX) {
                                    byte [] POWA = new byte[4];
                                    POWA [0] = txValue[3];
                                    POWA [1] = txValue[2];
                                    POWA [2] = txValue[1];
                                    POWA [3] = txValue[0];
                                    powerRX = false;
                                    power_value = bytearray2float(POWA);
                                    power_text.setText("Power: " + power_value);
                                    Log.d(TAG, "[0] = "+ txValue[0]);
                                    Log.d(TAG, "[1] = "+ txValue[1]);
                                    Log.d(TAG, "[2] = "+ txValue[2]);
                                    Log.d(TAG, "[3] = " + txValue[3]);

                                }


                                //messageListView.smoothScrollToPosition(listAdapter.getCount() - 1);
                            } catch (Exception e) {
                                Log.e(TAG, e.toString());
                            }
                        }
                    });
                }
            }

           //*********************//
            if (action.equals(UartService.DEVICE_DOES_NOT_SUPPORT_UART)){
            	showMessage("Device doesn't support UART. Disconnecting");
            	mService.disconnect();
            }

        }
    };

    private void printReceive() {
        for(int i = 0 ; i < xyz_size ; i++){

            Log.d(TAG, "Receive Data[" + i + "} = " + String.valueOf(ax[i]) +
                    ", " + String.valueOf(ay[i])+
                    ", " + String.valueOf(az[i]));

        }
    }


    private void service_init() {
        Intent bindIntent = new Intent(this, UartService.class);
        bindService(bindIntent, mServiceConnection, Context.BIND_AUTO_CREATE);
  
        LocalBroadcastManager.getInstance(this).registerReceiver(UARTStatusChangeReceiver, makeGattUpdateIntentFilter());
    }
    private void initiate_training(){

        reference_x = new float [data_num_elements *4 ];
        reference_y = new float [data_num_elements *4 ];
        reference_z = new float [data_num_elements *4 ];
        workspace = new float[6200];


        Log.d(TAG, " Initiating training algorithm");
        timer.setText("Generating Reference Data");

        Log.d(TAG,"Num of samples acquired = " + number_of_samples_acquired);


        ax[0] = ax[1];
        ay[0] = ay[1];
        az[0] = az[1];


        Log.d(TAG, "Done with training algorithm");

        //HERE
        for(int x = 0 ; x < 150  ; x++){
            Log.d(TAG, "TRAINING OUT[" + x + "} = " + String.valueOf(reference_x[x]) +
                    ", " + String.valueOf(reference_y[x])+
                    ", " + String.valueOf(reference_z[x]));
        }

        Log.d(TAG, "Done with getting references");

        Log.d(TAG, "Done with pre_ref");

        Log.d(TAG, "Done with pre_ref get references");

        float[] tx_reference_x = Arrays.copyOfRange(reference_x, 0, data_freq_downsamp_num_elements);
        float[] tx_reference_y = Arrays.copyOfRange(reference_y, 0, data_freq_downsamp_num_elements);
        float[] tx_reference_z = Arrays.copyOfRange(reference_z, 0, data_freq_downsamp_num_elements);


        Log.d(TAG, "Length = " + tx_reference_x.length);


        for(int x = 0 ; x < tx_reference_x.length  ; x++){
            Log.d(TAG, "REFERENCE OUT[" + x + "} = " + String.valueOf(tx_reference_x[x]) +
                    ", " + String.valueOf(tx_reference_y[x])+
                    ", " + String.valueOf(tx_reference_z[x]));
        }
        //for (int g = 0 ; g < reference_x.length ; g++){
        //    reference_x[g] = reference_x[g]/100;
        //    reference_y[g] = reference_y[g]/100;
        //}



        //turn the float reference data into bytes
        reference_x_bytes = FloatArray2ByteArray(tx_reference_x) ;
        reference_y_bytes = FloatArray2ByteArray(tx_reference_y);
        reference_z_bytes = FloatArray2ByteArray(tx_reference_z);
        reference_x_bytes = ChangeEdianness(reference_x_bytes);
        reference_y_bytes = ChangeEdianness(reference_y_bytes);
        reference_z_bytes = ChangeEdianness(reference_z_bytes);


        timer.setText("Sending Reference Data");

        byte [] value = new byte[1];

        value[0] = 6;
        Log.d(TAG, "Sending an 6! ");
        mService.writeRXCharacteristic(value);//Send Acc training Data to the App
        int index;
        for( index = 0 ; index < (reference_x_bytes.length - 8)/20 ; index++){
            try {
                Thread.sleep(50);//50 works
                mService.writeRXCharacteristic(Arrays.copyOfRange(reference_x_bytes, index * 20, index * 20 + 20));
            } catch(InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }


        byte [] special_data = Arrays.copyOfRange(reference_x_bytes,index * 20 , index * 20 + 9);
        special_data[8] = 7;

        try {
            Thread.sleep(50);//50 works
            mService.writeRXCharacteristic(special_data);
        } catch(InterruptedException ex) {
            Thread.currentThread().interrupt();
        }

        Log.d(TAG, "Sending an 7! ");

        for( index = 0; index < (reference_y_bytes.length - 8)/20 ; index++){
            try {
                Thread.sleep(50);//50 works
                mService.writeRXCharacteristic(Arrays.copyOfRange(reference_y_bytes, index * 20, index * 20 + 20));
            } catch(InterruptedException ex) {
                Thread.currentThread().interrupt();
           }

        }

        special_data = Arrays.copyOfRange(reference_y_bytes,index * 20 , index * 20 + 9);
        special_data[8] = trainingIDSelector;

        try {
            Thread.sleep(50);//50 works
            mService.writeRXCharacteristic(special_data);
        } catch(InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
        Log.d(TAG, "Sending " + special_data[8] + " !");
        timer.setText("Done Sending Reference Data");

        ax = null;
        ay = null;
        az = null;
        reference_x = null;
        reference_y = null;
        reference_z = null;
        workspace = null;
        //------------->>>>>>>>>> SEND A UNIQUE ID TO BE ABLE TO IDENTIFY ACTIVITY IN REAL TIME CLASSIFICATION ALGORITHM

        //for(int x = 0 ; x < 150 ; x++){
        //    Log.d(TAG, "ref_y[" + x + "} = " + String.valueOf(reference_y[x]));
        //}
    }
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UartService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(UartService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(UartService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(UartService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(UartService.DEVICE_DOES_NOT_SUPPORT_UART);
        return intentFilter;
    }
    @Override
    public void onStart() {
        Log.d(TAG, "onStart");
        super.onStart();
    }

    @Override
    public void onDestroy() {
    	 super.onDestroy();
        Log.d(TAG, "onDestroy()");
        
        try {
        	LocalBroadcastManager.getInstance(this).unregisterReceiver(UARTStatusChangeReceiver);
        } catch (Exception ignore) {
            Log.e(TAG, ignore.toString());
        } 
        unbindService(mServiceConnection);
        mService.stopSelf();
        mService= null;
       
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop");
        super.onStop();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause");
        super.onPause();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart");


    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume:D");
        if (!mBtAdapter.isEnabled()) {
            Log.i(TAG, "onResume - BT not enabled yet");
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }
 
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.d(TAG, "RequestCode = " + requestCode);
        Log.d(TAG, "ResultCode = " + resultCode);


        switch (requestCode) {
        case REQUEST_SELECT_DEVICE:
        	//When the DeviceListActivity return, with the selected device address
            if (resultCode == Activity.RESULT_OK && data != null) {
                String deviceAddress = data.getStringExtra(BluetoothDevice.EXTRA_DEVICE);
                mDevice = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(deviceAddress);
               
                Log.d(TAG, "... onActivityResultdevice.address==" + mDevice + "mserviceValue" + mService);
                ((TextView) findViewById(R.id.deviceName)).setText(mDevice.getName()+ " - connecting");
                mService.connect(deviceAddress);
                            

            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(this, "Bluetooth has turned on ", Toast.LENGTH_SHORT).show();

            } else {
                // User did not enable Bluetooth or an error occurred
                Log.d(TAG, "BT not enabled");
                Toast.makeText(this, "Problem in BT Turning ON ", Toast.LENGTH_SHORT).show();
                finish();
            }
            break;
            case USER_PROFILE_INPUT:
                if(resultCode == RESULT_OK){
                    Age[0] = (byte) data.getIntExtra("Age", -1);
                    Height = data.getFloatExtra("Height", -1);
                    Weight = data.getFloatExtra("Weight", -1);
                    Sex[0] = (byte) data.getIntExtra("Sex", -1);
                    //SEND THIS DATA TO MSP432

                    byte [] HeightByte = float2ByteArray(Height);
                    byte [] WeightByte = float2ByteArray(Weight);
                    HeightByte = ChangeEdianness(HeightByte);
                    WeightByte = ChangeEdianness(WeightByte);

                   byte [] UserConfiguration = new byte[WeightByte.length + HeightByte.length + 2];
                    System.arraycopy(HeightByte,0, UserConfiguration,0 , HeightByte.length);
                    System.arraycopy(WeightByte,0, UserConfiguration, HeightByte.length , WeightByte.length);
                    System.arraycopy(Sex, 0, UserConfiguration, 8, 1);
                    System.arraycopy(Age, 0 , UserConfiguration, 9, 1);


                    Log.d(TAG, "UserConfiguration Length = " + UserConfiguration.length);
                    int f;
                    for(f = 0 ; f < UserConfiguration.length ; f++){
                        Log.d(TAG, "UserConfiguration = " + UserConfiguration[f]);
                    }


                    mService.writeRXCharacteristic(UserConfiguration);//Send Acc training Data to the App
                }
                break;
            case TRAINING_DEVICE:
                if(resultCode == RESULT_OK){
                    trainingIDSelector = (byte) data.getIntExtra("trainingID", -1);
                    Log.d(TAG, "trainingIDSelector = " + trainingIDSelector);
                    byte[] value = new byte[1];

                    //TELL MSP432 TO START TRAINING
                    long secTicks = 0;
                    switch(trainingIDSelector){
                        case 30:
                            value[0] = 30;
                            secTicks = 30000;
                            xyz_size = (int)(30.0f * sampling_freq);
                            break;
                        case 45:
                            value[0] = 45;
                            secTicks = 45000;
                            xyz_size = (int)(45.0f * sampling_freq);
                            break;
                        default:
                            value[0] = 30;
                            secTicks = 30000;
                            xyz_size = (int)(30.0f * sampling_freq);
                            break;
                    }


                            Log.d(TAG, "Sending " + value[0] + "!");
                            mService.writeRXCharacteristic(value);//Tell the MSP432 to begin collecting 30 sec of training data

                            new CountDownTimer(secTicks, 1000) { //Sets a 30 second remaining down counter

                                public void onTick(long millisUntilFinished) {
                                    timer.setText("COLLECTING DATA, SECONDS REMAINING: " + millisUntilFinished / 1000);
                                }

                                public void onFinish() {
                                    byte[] value = new byte[1];
                                    value[0] = 2;
                                    Log.d(TAG, "Sending 2!");
                                    mService.writeRXCharacteristic(value);//Send Acc training Data to the App
                                    timer.setText("Uploading data to android device!");
                                }
                            }.start();

                }
                break;
        default:
            Log.e(TAG, "wrong request code");
            break;
        }



    }



    
    private void showMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
  
    }

    @Override
    public void onBackPressed() {
        if (mState == UART_PROFILE_CONNECTED) {
            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
            showMessage("nRFUART's running in background.\n             Disconnect to exit");
        }
        else {
            new AlertDialog.Builder(this)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setTitle(R.string.popup_title)
            .setMessage(R.string.popup_message)
            .setPositiveButton(R.string.popup_yes, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
   	                finish();
                }
            })
            .setNegativeButton(R.string.popup_no, null)
            .show();
        }
    }
    public static byte[] FloatArray2ByteArray(float[] values){
        ByteBuffer buffer = ByteBuffer.allocate(4 * values.length);

        for (float value : values){
            buffer.putFloat(value);
        }

        return buffer.array();
    }
    public static byte [] ChangeEdianness(byte Value[]){
        byte newValue[] = new byte[Value.length];
        for (int i = 0 ; i < Value.length ; i+=4){
            newValue [i]  = Value [i + 3]; //i = 4
            newValue [i+1]  = Value [i + 2];
            newValue [i+2]  = Value [i + 1];
            newValue [i+3]  = Value [i];
            //i+e;
        }
       // for (int i = 0 ; i < newValue.length ; i++) {
       //     Log.d(TAG, " " + i  + " " + String.valueOf(newValue[i]));
       // }

        return newValue;
    }
    public static byte [] float2ByteArray (float value)
    {
        return ByteBuffer.allocate(4).putFloat(value).array();
    }
    public static float bytearray2float(byte[] b) {


        ByteBuffer buf = ByteBuffer.wrap(b);
        return buf.getFloat();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.action_settings:
                Intent intent = new Intent(this, ActivityForItemOne.class);
                startActivityForResult(intent, USER_PROFILE_INPUT);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }

        return true;
    }

    static float [] sine(	float [] data,
                             float omega,
                             float phase,
                             float amplitude,
                             float time_length,
                             float samp_freq){


        int k;
        int N = (int)(time_length * samp_freq);
        float dt = 1.0f / samp_freq;

        for (k = 0; k < N; k++)
        {
            data[k] = amplitude * ((float)Math.sin( omega * (k * dt) + phase));
        }
        return data;
    }

}
